"use client";
 
import { useState, useRef, useEffect, useCallback } from "react";
import {
  Plus, ChevronRight, ChevronDown, ChevronUp, ChevronLeft,
  Search, Filter, Pencil, Trash2, Upload, Send, RotateCcw,
  Coffee, X, Check, RefreshCw, Loader2, Image, Star,
} from "lucide-react";
import "../menucategorypage/designmenucategorypage.css";
import {
  createCategory, getCategoriesByAdmin, updateCategory, deleteCategory,
  createProduct, getProductsByCategory, updateProduct, deleteProduct,
  updateProductAvailability,
} from "../services/menuService";
import { uploadCategoryImage, uploadProductImage } from "../services/imageservice";
import api from "../services/axiosInterceptor";
import { useCurrency } from "../context/CurrencyContext";
import { getCurrencySymbol, formatCurrency } from "../utils/currencyHelper";
import { useLanguage } from "../context/LanguageContext";

const ITEMS_PER_PAGE = 5;
const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB

function getUser() {
  try { const s = localStorage.getItem("ttl_user"); return s ? JSON.parse(s) : null; }
  catch { return null; }
}

function Toast({ msg, type }) {
  return (
    <div style={{
      position: "fixed", bottom: 28, left: "50%", transform: "translateX(-50%)",
      background: type === "error" ? "#dc2626" : "#18181b",
      color: "#fff", padding: "11px 24px", borderRadius: 30,
      fontSize: 13.5, fontWeight: 600, zIndex: 9999,
      boxShadow: "0 4px 20px rgba(0,0,0,0.18)", whiteSpace: "nowrap",
      animation: "mcToastIn 0.25s ease",
    }}>
      <style>{`@keyframes mcToastIn{from{opacity:0;transform:translateX(-50%) translateY(10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}`}</style>
      {msg}
    </div>
  );
}

function ImageUploadBox({ imageUrl, onUpload, onRemove, uploading, compact, t }) {
  const inputRef = useRef();
  const handle = (e) => { const f = e.target.files[0]; if (f) onUpload(f); e.target.value = ""; };

  if (compact) {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <input ref={inputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handle} />
        {imageUrl ? (
          <div style={{ position: "relative", display: "inline-flex" }}>
            <img src={imageUrl} alt="cat" style={{ width: 38, height: 38, objectFit: "cover", borderRadius: 8, border: "1.5px solid #e4e4e7" }} />
            <button type="button" onClick={onRemove} style={{ position: "absolute", top: -6, right: -6, width: 18, height: 18, background: "#ef4444", border: "2px solid #fff", borderRadius: "50%", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", padding: 0 }}><X size={10} /></button>
          </div>
        ) : (
          <div onClick={() => inputRef.current?.click()} style={{ width: 38, height: 38, borderRadius: 8, background: "#f4f3f0", border: "1.5px dashed #d4d4d8", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#a1a1aa", flexShrink: 0 }}>
            {uploading ? <Loader2 size={14} style={{ animation: "spin .7s linear infinite" }} /> : <Image size={15} />}
          </div>
        )}
        <span style={{ fontSize: 12, color: "#a1a1aa" }}>{uploading ? t("mc_uploading") : imageUrl ? t("mc_image_uploaded") : t("mc_optional_add_image")}</span>
      </div>
    );
  }

  return (
    <>
      <input ref={inputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handle} />
      {imageUrl ? (
        <div style={{ position: "relative", display: "inline-flex" }}>
          <img src={imageUrl} alt="preview" style={{ width: 100, height: 100, objectFit: "cover", borderRadius: 10, border: "1.5px solid #e4e4e7" }} />
          <button type="button" onClick={onRemove} style={{ position: "absolute", top: -7, right: -7, width: 20, height: 20, background: "#ef4444", border: "2px solid #fff", borderRadius: "50%", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", padding: 0, zIndex: 2 }}><X size={11} /></button>
        </div>
      ) : (
        <div className="mc-upload-zone" onClick={() => inputRef.current?.click()} role="button" tabIndex={0} onKeyDown={e => e.key === "Enter" && inputRef.current?.click()}>
          {uploading
            ? <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}><Loader2 size={24} style={{ animation: "spin .7s linear infinite", color: "#3b1f0a" }} /><span className="mc-upload-text">{t("mc_uploading")}</span></div>
            : <><Upload size={24} className="mc-upload-icon" /><span className="mc-upload-text">{t("mc_click_upload")}</span><span className="mc-upload-hint">{t("mc_png_jpg_hint")}</span></>}
        </div>
      )}
    </>
  );
}

// ── MAIN COMPONENT ──────────────────────────────────────────
const MenuCategory = () => {
  const { t } = useLanguage();
  const user       = getUser();
  const adminId    = user?.adminId    || "";
  const businessId = user?.businessId || "";
  const { currencyCode, currencyReady } = useCurrency();

  const [businessType,       setBusinessType]       = useState("");
  const [editingCatId,       setEditingCatId]       = useState(null);
  const [editCatName,        setEditCatName]        = useState("");
  const [editCatImageUrl,    setEditCatImageUrl]    = useState(null);
  const [editCatImgUploading,setEditCatImgUploading]= useState(false);
  const [categories,         setCategories]         = useState([]);
  const [products,           setProducts]           = useState([]);
  const [selectedCatId,      setSelectedCatId]      = useState(null);
  const [formCollapsed,      setFormCollapsed]      = useState(false);
  const [showAddCatInline,   setShowAddCatInline]   = useState(false);
  const [newCatName,         setNewCatName]         = useState("");
  const [newCatImageUrl,     setNewCatImageUrl]     = useState(null);
  const [newCatImgUploading, setNewCatImgUploading] = useState(false);
  const [searchQuery,        setSearchQuery]        = useState("");
  const [statusFilter,       setStatusFilter]       = useState("All Status");
  const [currentPage,        setCurrentPage]        = useState(1);
  const [editingItem,        setEditingItem]        = useState(null);
  const [showDeleteModal,    setShowDeleteModal]    = useState(false);
  const [deleteTarget,       setDeleteTarget]       = useState(null);
  const [catsLoading,        setCatsLoading]        = useState(true);
  const [prodsLoading,       setProdsLoading]       = useState(false);
  const [formSaving,         setFormSaving]         = useState(false);
  const [catSaving,          setCatSaving]          = useState(false);
  const [deleting,           setDeleting]           = useState(false);
  const [toast,              setToast]              = useState(null);
  const [prodImgUploading,   setProdImgUploading]   = useState(false);
  const [availabilitySavingId, setAvailabilitySavingId] = useState(null); // productId currently being toggled
  const [specialSavingId, setSpecialSavingId] = useState(null); // productId currently having "special" toggled

  // ── Suggestion states ───────────────────────────────────
  const [catSuggestions,    setCatSuggestions]    = useState([]);  // [{categoryName, categoryEmoji}]
  const [itemSuggestions,   setItemSuggestions]   = useState([]);  // [{itemName}]
  const [loadingItemSugg,   setLoadingItemSugg]   = useState(false);
  // For sidebar add-category inline
  const [showCatSuggDrop,   setShowCatSuggDrop]   = useState(false);
  // For form category suggestion
  const [showFormCatDrop,   setShowFormCatDrop]   = useState(false);
  const [showFormItemDrop,  setShowFormItemDrop]  = useState(false);

  const [form, setForm] = useState({
    categoryId: "", newCategoryName: "", name: "", description: "",
    price: "", status: "ACTIVE", imageUrl: null, itemAvailability: "AVAILABLE",
    specialItem: false,
  });
  const [formErrors, setFormErrors] = useState({});

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type }); setTimeout(() => setToast(null), 3000);
  }, []);

  // Load category suggestions — backend auto-resolves businessType from JWT
  useEffect(() => {
    if (!adminId) return;
    api.get("/api/suggestions/categories")
      .then(res => {
        const data = res.data?.data || [];
        setCatSuggestions(data);
        console.log("Cat suggestions loaded:", data.length);
      })
      .catch(err => {
        console.error("Cat suggestions error:", err?.response?.status, err?.response?.data);
        setCatSuggestions([]);
      });
  }, [adminId]);

  // Load item suggestions when category changes
  const loadItemSuggestions = useCallback(async (categoryName) => {
    if (!categoryName) { setItemSuggestions([]); return; }
    setLoadingItemSugg(true);
    try {
      const res = await api.get(`/api/suggestions/items?categoryName=${encodeURIComponent(categoryName)}`);
      const data = res.data?.data || [];
      setItemSuggestions(data);
      console.log("Item suggestions for", categoryName, ":", data.length);
    } catch (err) {
      console.error("Item suggestions error:", err?.response?.status, err?.response?.data);
      setItemSuggestions([]);
    } finally {
      setLoadingItemSugg(false);
    }
  }, []);

  // Trigger item suggestions load when category selection changes
  useEffect(() => {
    if (form.categoryId) {
      const cat = categories.find(c => String(c.categoryId) === String(form.categoryId));
      if (cat) loadItemSuggestions(cat.categoryName);
    } else if (form.newCategoryName.trim()) {
      loadItemSuggestions(form.newCategoryName.trim());
    } else {
      setItemSuggestions([]);
    }
  }, [form.categoryId, form.newCategoryName, categories, loadItemSuggestions]);

  const fetchCategories = useCallback(async () => {
    if (!adminId) return;
    setCatsLoading(true);
    try { const res = await getCategoriesByAdmin(adminId); setCategories(res.data || []); }
    catch { showToast(t("mc_could_not_load_cats"), "error"); }
    finally { setCatsLoading(false); }
  }, [adminId, showToast]);

  const fetchProducts = useCallback(async (catId) => {
    if (!catId) return;
    setProdsLoading(true);
    try { const res = await getProductsByCategory(catId); setProducts(res.data || []); }
    catch { showToast(t("mc_could_not_load_items"), "error"); }
    finally { setProdsLoading(false); }
  }, [showToast]);

  useEffect(() => { fetchCategories(); }, [fetchCategories]);
  useEffect(() => { if (selectedCatId) fetchProducts(selectedCatId); else setProducts([]); }, [selectedCatId, fetchProducts]);

  const handleEditCategory = (cat, e) => {
    e.stopPropagation();
    setEditingCatId(cat.categoryId);
    setEditCatName(cat.categoryName);
    setEditCatImageUrl(cat.categoryImageUrl || null);
  };

  const handleUpdateCategory = async (cat, e) => {
    e.stopPropagation();
    if (!editCatName.trim()) return;
    try {
      await updateCategory(cat.categoryId, adminId, {
        adminId,
        businessId,
        categoryName:     editCatName.trim(),
        categoryImageUrl: editCatImageUrl || null,
        categoryStatus:   "ACTIVE",
      });
      setEditingCatId(null);
      fetchCategories();
      showToast("Category updated! ✓");
    } catch { showToast(t("mc_could_not_update_cat"), "error"); }
  };

  const handleEditCatImageUpload = async (file) => {
    if (file.size > MAX_IMAGE_BYTES) { showToast("Image must be smaller than 5MB.", "error"); return; }
    setEditCatImgUploading(true);
    try {
      const res = await uploadCategoryImage(file);
      setEditCatImageUrl(res.data?.data?.imageUrl || res.data?.imageUrl || null);
    } catch { showToast(t("mc_could_not_upload_image"), "error"); }
    finally { setEditCatImgUploading(false); }
  };

  const handleSelectCategory = (catId) => {
    setSelectedCatId(catId); setCurrentPage(1); setSearchQuery(""); setStatusFilter("All Status");
    // Pre-fill the item form's Category field with whichever category was
    // just clicked in the sidebar — the merchant already told us which
    // category they're working in, so the form shouldn't ask again.
    resetItemFieldsKeepCategory(catId);
  };

  const handleCatImageUpload = async (file) => {
    if (file.size > MAX_IMAGE_BYTES) { showToast("Image must be smaller than 5MB.", "error"); return; }
    setNewCatImgUploading(true);
    try { const res = await uploadCategoryImage(file); setNewCatImageUrl(res.data?.data?.imageUrl || res.data?.imageUrl || null); }
    catch { showToast(t("mc_could_not_upload_image"), "error"); }
    finally { setNewCatImgUploading(false); }
  };

  const handleProdImageUpload = async (file) => {
    if (file.size > MAX_IMAGE_BYTES) { showToast("Image must be smaller than 5MB.", "error"); return; }
    setProdImgUploading(true);
    try { const res = await uploadProductImage(file); setForm(prev => ({ ...prev, imageUrl: res.data?.data?.imageUrl || res.data?.imageUrl || null })); }
    catch { showToast(t("mc_could_not_upload_image"), "error"); }
    finally { setProdImgUploading(false); }
  };

  const handleAddCategory = async () => {
    if (!newCatName.trim()) return;
    setCatSaving(true);
    try {
      const res = await createCategory({ adminId, businessId, categoryName: newCatName.trim(), categoryImageUrl: newCatImageUrl || null });
      const created = res.data;
      setCategories(prev => [created, ...prev]);
      setSelectedCatId(created.categoryId);
      // Pre-fill the item form's Category field too — the merchant just
      // created this category specifically to add items to it, so the
      // form shouldn't make them pick it again from the dropdown.
      resetItemFieldsKeepCategory(created.categoryId);
      setNewCatName(""); setNewCatImageUrl(null); setShowAddCatInline(false);
      showToast(t("mc_category_created"));
    } catch (err) {
      showToast(err.response?.data?.message || t("mc_could_not_create_cat"), "error");
    } finally { setCatSaving(false); }
  };

  const handleDeleteCategory = async (catId) => {
    setDeleting(true);
    try {
      await deleteCategory(catId, adminId);
      setCategories(prev => prev.filter(c => c.categoryId !== catId));
      if (selectedCatId === catId) { setSelectedCatId(null); setProducts([]); }
      showToast(t("mc_category_deleted"));
    } catch (err) {
      showToast(err.response?.data?.message || t("mc_could_not_delete"), "error");
    } finally { setDeleting(false); setShowDeleteModal(false); setDeleteTarget(null); }
  };

  const resetItemFieldsKeepCategory = useCallback((keepCatId) => {
    setForm({
      categoryId: keepCatId ? String(keepCatId) : "",
      newCategoryName: "", name: "", description: "", price: "", status: "ACTIVE", imageUrl: null,
      itemAvailability: "AVAILABLE", specialItem: false,
    });
    setFormErrors({}); setEditingItem(null); setItemSuggestions([]);
  }, []);

  const resetForm = useCallback(() => {
    setForm({ categoryId: "", newCategoryName: "", name: "", description: "", price: "", status: "ACTIVE", imageUrl: null, itemAvailability: "AVAILABLE", specialItem: false });
    setFormErrors({}); setEditingItem(null); setItemSuggestions([]);
  }, []);

  const handleFieldChange = useCallback((field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setFormErrors(prev => ({ ...prev, [field]: "" }));
  }, []);

  const validateForm = () => {
    const errors = {};
    const hasCat = form.categoryId || form.newCategoryName.trim();
    if (!hasCat) errors.category = t("mc_err_select_category");
    if (!form.name.trim()) errors.name = t("mc_err_name_required");
    const p = parseFloat(form.price);
    if (form.price === "" || isNaN(p) || p < 0) errors.price = "Enter a valid price.";
    return errors;
  };

  const handleSaveItem = async () => {
    const errors = validateForm();
    if (Object.keys(errors).length) { setFormErrors(errors); return; }
    setFormSaving(true);
    try {
      let targetCatId = form.categoryId ? Number(form.categoryId) : selectedCatId;

      if (form.newCategoryName.trim()) {
        const existing = categories.find(c => c.categoryName.toLowerCase() === form.newCategoryName.trim().toLowerCase());
        if (existing) { targetCatId = existing.categoryId; }
        else {
          const catRes = await createCategory({ adminId, businessId, categoryName: form.newCategoryName.trim() });
          const newCat = catRes.data;
          setCategories(prev => [newCat, ...prev]);
          targetCatId = newCat.categoryId;
        }
      }

      const payload = {
        adminId, businessId, categoryId: targetCatId,
        itemName: form.name.trim(), itemDescription: form.description.trim() || null,
        itemPrice: parseFloat(form.price), itemImageUrl: form.imageUrl || null,
        productStatus: form.status,
        itemAvailability: form.itemAvailability || "AVAILABLE",
        specialItem: !!form.specialItem,
      };

      if (editingItem) {
        const res = await updateProduct(editingItem.productId, adminId, payload);
        setProducts(prev => prev.map(p => p.productId === editingItem.productId ? res.data : p));
        showToast(t("mc_item_updated"));
      } else {
        const res = await createProduct(payload);
        if (targetCatId === selectedCatId) setProducts(prev => [res.data, ...prev]);
        else setSelectedCatId(targetCatId);
        setCategories(prev => prev.map(c => c.categoryId === targetCatId ? { ...c, productCount: c.productCount + 1 } : c));
        showToast(t("mc_item_saved"));
      }
      // Keep the category the merchant just used pre-selected, instead of
      // wiping the whole form — whether they typed a brand-new category
      // name or picked one from the dropdown, adding the next item to the
      // same category shouldn't require re-entering it every time.
      resetItemFieldsKeepCategory(targetCatId); setCurrentPage(1);
    } catch (err) {
      showToast(err.response?.data?.message || t("mc_could_not_save_item"), "error");
    } finally { setFormSaving(false); }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setForm({ categoryId: String(item.categoryId), newCategoryName: "", name: item.itemName, description: item.itemDescription || "", price: String(item.itemPrice), status: item.productStatus, imageUrl: item.itemImageUrl || null, itemAvailability: item.itemAvailability || "AVAILABLE", specialItem: !!item.specialItem });
    setFormErrors({}); setFormCollapsed(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Quick in-stock / out-of-stock toggle straight from the items table —
  // no need to open the edit form just to flip availability.
  const handleToggleAvailability = async (item) => {
    const next = item.itemAvailability === "OUT_OF_STOCK" ? "AVAILABLE" : "OUT_OF_STOCK";
    setAvailabilitySavingId(item.productId);
    try {
      const res = await updateProductAvailability(item.productId, adminId, next);
      setProducts(prev => prev.map(p => p.productId === item.productId ? { ...p, itemAvailability: res.data?.itemAvailability || next } : p));
      showToast(next === "OUT_OF_STOCK" ? t("mc_marked_out_of_stock") : t("mc_marked_available"));
    } catch (err) {
      showToast(err.response?.data?.message || t("mc_could_not_update_availability"), "error");
    } finally {
      setAvailabilitySavingId(null);
    }
  };

  // Quick "Special Item" (⭐) toggle straight from the items table — sends
  // the item's existing full payload with just the flag flipped, since
  // there's no dedicated PATCH endpoint for this field (unlike availability).
  const handleToggleSpecial = async (item) => {
    const nextSpecial = !item.specialItem;
    setSpecialSavingId(item.productId);
    try {
      const payload = {
        adminId, businessId, categoryId: item.categoryId,
        itemName: item.itemName, itemDescription: item.itemDescription || null,
        itemPrice: item.itemPrice, itemImageUrl: item.itemImageUrl || null,
        productStatus: item.productStatus, itemAvailability: item.itemAvailability || "AVAILABLE",
        specialItem: nextSpecial,
      };
      const res = await updateProduct(item.productId, adminId, payload);
      setProducts(prev => prev.map(p => p.productId === item.productId ? { ...p, specialItem: !!res.data?.specialItem } : p));
      showToast(nextSpecial ? t("mc_marked_special") : t("mc_unmarked_special"));
    } catch (err) {
      showToast(err.response?.data?.message || t("mc_could_not_update_special"), "error");
    } finally {
      setSpecialSavingId(null);
    }
  };

  const openDeleteModal = (target) => { setDeleteTarget(target); setShowDeleteModal(true); };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    if (deleteTarget.type === "product") {
      setDeleting(true);
      try {
        await deleteProduct(deleteTarget.id, adminId);
        setProducts(prev => prev.filter(p => p.productId !== deleteTarget.id));
        setCategories(prev => prev.map(c => c.categoryId === selectedCatId ? { ...c, productCount: Math.max(0, c.productCount - 1) } : c));
        showToast(t("mc_item_deleted"));
      } catch (err) { showToast(err.response?.data?.message || t("mc_could_not_delete"), "error"); }
      finally { setDeleting(false); }
    } else if (deleteTarget.type === "category") {
      await handleDeleteCategory(deleteTarget.id);
    }
    setShowDeleteModal(false); setDeleteTarget(null); setCurrentPage(1);
  };

  const selectedCategory  = categories.find(c => c.categoryId === selectedCatId);
  const filteredProducts  = products.filter(p => {
    const ms = p.itemName.toLowerCase().includes(searchQuery.toLowerCase()) || (p.itemDescription || "").toLowerCase().includes(searchQuery.toLowerCase());
    const mst = statusFilter === "All Status" || (statusFilter === "Active" && p.productStatus === "ACTIVE") || (statusFilter === "Inactive" && p.productStatus === "INACTIVE");
    return ms && mst;
  });
  const totalPages    = Math.max(1, Math.ceil(filteredProducts.length / ITEMS_PER_PAGE));
  const safePage      = Math.min(currentPage, totalPages);
  const pagedProducts = filteredProducts.slice((safePage - 1) * ITEMS_PER_PAGE, safePage * ITEMS_PER_PAGE);
  const totalItems    = products.length;

  // current category name used to load item suggestions
  const currentCategoryName = form.categoryId
    ? (categories.find(c => String(c.categoryId) === String(form.categoryId))?.categoryName || "")
    : form.newCategoryName.trim();

  // ── INLINE STYLES ───────────────────────────────────────
  const suggDropStyle = {
    position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 200,
    background: "#fff", border: "1.5px solid #e4e4e7", borderRadius: 10,
    boxShadow: "0 8px 24px rgba(0,0,0,0.13)", maxHeight: 240, overflowY: "auto",
  };
  const suggItemStyle = (hover) => ({
    display: "flex", alignItems: "center", gap: 10, width: "100%",
    padding: "9px 14px", background: hover ? "#fffbeb" : "transparent",
    border: "none", textAlign: "left", cursor: "pointer",
    fontSize: 13, color: "#18181b", borderBottom: "1px solid #f9f9f9",
  });

  return (
    <div className="mc-root">
      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes mcToastIn{from{opacity:0;transform:translateX(-50%) translateY(10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
        .mc-btn-danger{display:inline-flex;align-items:center;gap:6px;background:#ef4444;border:none;color:#fff;border-radius:8px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer;transition:background .18s}
        .mc-btn-danger:hover{background:#dc2626}.mc-btn-danger:disabled{opacity:.6;cursor:not-allowed}
        .mc-add-cat-inline{padding:14px 16px;border-bottom:1px solid #f4f4f5;display:flex;flex-direction:column;gap:10px}
        .mc-inline-actions{display:flex;gap:8px;justify-content:flex-end}
        .mc-no-category{display:flex;flex-direction:column;align-items:center;text-align:center;padding:32px 20px;gap:10px;color:#71717a}
        .mc-no-category .mc-no-icon{font-size:36px}
        .mc-no-category h3{font-size:14px;font-weight:700;color:#18181b;margin:0}
        .mc-no-category p{font-size:12.5px;margin:0}
        .mc-no-category button{display:inline-flex;align-items:center;gap:6px;background:#3b1f0a;color:#fff;border:none;border-radius:8px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer;margin-top:4px}
        .mc-cat-row-actions{display:flex;align-items:center;gap:2px;margin-left:auto;padding-left:6px;flex-shrink:0}
        .mc-cat-icon-btn{background:none;border:none;color:#d4d4d8;cursor:pointer;padding:5px;border-radius:5px;display:flex;align-items:center;transition:color .18s,background .18s}
        .mc-cat-icon-btn:hover{color:#ef4444;background:#fee2e2}
        .sugg-drop-header{padding:7px 14px 5px;font-size:10.5px;color:#a1a1aa;font-weight:700;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #f4f4f5}
      `}</style>

      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {showDeleteModal && (
        <div className="mc-modal-overlay" onClick={() => !deleting && setShowDeleteModal(false)}>
          <div className="mc-modal" onClick={e => e.stopPropagation()}>
            <div className="mc-modal-head">
              <span className="mc-modal-title">{deleteTarget?.type === "category" ? t("mc_delete_category") : t("mc_delete_item")}</span>
              <button className="mc-modal-close" onClick={() => !deleting && setShowDeleteModal(false)} type="button"><X size={20} /></button>
            </div>
            <div className="mc-modal-body">
              <p style={{ fontSize: 13.5, color: "#3f3f46" }}>
                {deleteTarget?.type === "category" ? t("mc_delete_cat_warn") : t("mc_delete_item_warn")}
              </p>
            </div>
            <div className="mc-modal-foot">
              <button className="mc-btn-ghost" onClick={() => setShowDeleteModal(false)} disabled={deleting} type="button">{t("mc_cancel")}</button>
              <button className="mc-btn-danger" onClick={confirmDelete} disabled={deleting} type="button">
                {deleting ? <><Loader2 size={14} style={{ animation: "spin .7s linear infinite" }} /> {t("mc_deleting")}</> : t("mc_yes_delete")}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="mc-page-header">
        <div className="mc-page-title-row">
          <div>
            <h1 className="mc-page-title">{t("mc_page_title")}</h1>
            <p className="mc-page-sub">{t("mc_page_sub")}</p>
          </div>
        </div>
      </div>

      <div className="mc-layout">
        {/* ── SIDEBAR ─────────────────────────────────────── */}
        <aside className="mc-sidebar">
          <div className="mc-sidebar-head">
            <span className="mc-sidebar-title">{t("mc_categories")} {!catsLoading && `(${categories.length})`}</span>
            <button className="mc-btn-outline-sm" onClick={() => setShowAddCatInline(true)} type="button"><Plus size={14} /> {t("mc_add")}</button>
          </div>

          {showAddCatInline && (
            <div className="mc-add-cat-inline">

              {/* Category suggestion dropdown for sidebar */}
              {catSuggestions.length > 0 && (
                <div style={{ position: "relative" }}>
                  <div style={{ marginBottom: 6 }}>
                    <button
                      type="button"
                      onClick={() => setShowCatSuggDrop(v => !v)}
                      style={{
                        display: "flex", alignItems: "center", gap: 6, width: "100%",
                        padding: "8px 12px", background: "#fffbeb", border: "1.5px solid #fde68a",
                        borderRadius: 8, fontSize: 12.5, fontWeight: 600, color: "#92400e", cursor: "pointer",
                        justifyContent: "space-between"
                      }}
                    >
                      <span>{t("mc_pick_suggestions")} ({catSuggestions.length})</span>
                      <ChevronDown size={14} style={{ transform: showCatSuggDrop ? "rotate(180deg)" : "none", transition: "0.2s" }} />
                    </button>
                    {showCatSuggDrop && (
                      <div style={suggDropStyle}>
                        <div className="sugg-drop-header">{t("mc_suggestions_for_type")}</div>
                        {catSuggestions.map((s, i) => (
                          <button key={i} type="button"
                            style={suggItemStyle(false)}
                            onMouseEnter={e => e.currentTarget.style.background = "#fffbeb"}
                            onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                            onClick={() => { setNewCatName(s.categoryName); if(s.categoryImage) setNewCatImageUrl(s.categoryImage); setShowCatSuggDrop(false); }}
                          >
                            {s.categoryEmoji && <span style={{ fontSize: 16 }}>{s.categoryEmoji}</span>}
                            <span>{s.categoryName}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              <input
                className="mc-input" type="text"
                placeholder={t("mc_category_name_ph")}
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleAddCategory()}
                autoFocus
              />
              <ImageUploadBox imageUrl={newCatImageUrl} onUpload={handleCatImageUpload} onRemove={() => setNewCatImageUrl(null)} uploading={newCatImgUploading} compact t={t} />
              <div className="mc-inline-actions">
                <button className="mc-btn-ghost" onClick={() => { setShowAddCatInline(false); setNewCatName(""); setNewCatImageUrl(null); setShowCatSuggDrop(false); }} disabled={catSaving} type="button">{t("mc_cancel")}</button>
                <button className="mc-btn-dark shadow-sm hover:shadow-md active:translate-y-0 transition-all duration-200" onClick={handleAddCategory} disabled={catSaving || !newCatName.trim()} type="button">
                  {catSaving ? <><Loader2 size={14} style={{ animation: "spin .7s linear infinite" }} /> {t("mc_creating")}</> : <><Check size={14} /> {t("mc_create")}</>}
                </button>
              </div>
            </div>
          )}

          <div className="mc-cat-list">
            {catsLoading ? (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 32, gap: 10, color: "#71717a", fontSize: 13 }}>
                <Loader2 size={18} style={{ animation: "spin .7s linear infinite" }} /> {t("mc_loading")}
              </div>
            ) : categories.length === 0 ? (
              <div className="mc-no-category">
                <span className="mc-no-icon">📪</span>
                <h3>{t("mc_no_categories_title")}</h3>
                <p>{t("mc_no_categories_sub")}</p>
                <button onClick={() => setShowAddCatInline(true)} type="button"><Plus size={14} /> {t("mc_add_new_category")}</button>
              </div>
            ) : (
              categories.map(cat => (
                <div key={cat.categoryId}
                  className={`mc-cat-item ${selectedCatId === cat.categoryId ? "mc-cat-active" : ""} transition-all duration-200 hover:shadow-sm hover:-translate-y-0.5 rounded-xl`}
                  onClick={() => editingCatId !== cat.categoryId && handleSelectCategory(cat.categoryId)}
                  role="button" tabIndex={0}
                  style={{ position:"relative" }}
                  onKeyDown={e => e.key === "Enter" && handleSelectCategory(cat.categoryId)}>

                  {editingCatId === cat.categoryId ? (
                    /* ── Inline edit mode ── */
                    <div style={{ flex:1, display:"flex", flexDirection:"column", gap:6, padding:"4px 0" }} onClick={e=>e.stopPropagation()}>
                      {/* Image edit */}
                      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                        <div style={{ position:"relative", flexShrink:0 }}>
                          <div style={{ width:36, height:36, borderRadius:8, overflow:"hidden", background:"#f4f4f5", border:"1.5px dashed #d4d4d8", cursor:"pointer" }}
                            onClick={()=>document.getElementById(`edit-cat-img-${cat.categoryId}`)?.click()}>
                            {editCatImageUrl
                              ? <img src={editCatImageUrl} alt="" style={{ width:"100%", height:"100%", objectFit:"cover", display:"block" }}/>
                              : <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center" }}>
                                  {editCatImgUploading ? <Loader2 size={12} style={{ animation:"spin .7s linear infinite" }}/> : <Upload size={12} color="#a1a1aa"/>}
                                </div>}
                          </div>
                          <input id={`edit-cat-img-${cat.categoryId}`} type="file" accept="image/*" style={{ display:"none" }}
                            onChange={e=>{ const f=e.target.files[0]; if(f) handleEditCatImageUpload(f); e.target.value=""; }}/>
                        </div>
                        <input
                          autoFocus
                          value={editCatName}
                          onChange={e=>setEditCatName(e.target.value)}
                          onKeyDown={e=>{ if(e.key==="Enter") handleUpdateCategory(cat,e); if(e.key==="Escape"){ setEditingCatId(null); } }}
                          style={{ flex:1, padding:"5px 8px", borderRadius:7, border:"1.5px solid #7c3aed", fontSize:13, fontWeight:600, outline:"none", minWidth:0 }}
                        />
                      </div>
                      {/* Save/Cancel */}
                      <div style={{ display:"flex", gap:5 }}>
                        <button type="button" onClick={e=>handleUpdateCategory(cat,e)}
                          style={{ flex:1, padding:"4px 0", borderRadius:6, border:"none", background:"#7c3aed", color:"#fff", fontSize:11.5, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:4 }}>
                          <Check size={11}/> {t("mc_save")}
                        </button>
                        <button type="button" onClick={e=>{ e.stopPropagation(); setEditingCatId(null); }}
                          style={{ flex:1, padding:"4px 0", borderRadius:6, border:"1.5px solid #e4e4e7", background:"#fff", color:"#6b7280", fontSize:11.5, fontWeight:600, cursor:"pointer" }}>
                          {t("mc_cancel")}
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* ── Normal view mode ── */
                    <>
                      <div className="mc-cat-img">
                        {cat.categoryImageUrl ? <img src={cat.categoryImageUrl} alt={cat.categoryName} style={{ width:"100%", height:"100%", objectFit:"cover", borderRadius:8 }}/> : "🍽️"}
                      </div>
                      <div className="mc-cat-info">
                        <div className="mc-cat-name">{cat.categoryName}</div>
                        <div className="mc-cat-count">{cat.productCount} {t("mc_items_word")}</div>
                      </div>
                      <div className="mc-cat-row-actions" onClick={e => e.stopPropagation()}
                        style={{ display:"flex", alignItems:"center", gap:3, opacity:0, transition:"opacity 0.15s" }}
                        onMouseEnter={e=>e.currentTarget.style.opacity="1"}
                        onMouseLeave={e=>e.currentTarget.style.opacity="0"}>
                        <button className="mc-cat-icon-btn" title="Edit" type="button"
                          onClick={e=>handleEditCategory(cat,e)}
                          style={{ background:"#ede9fe", color:"#7c3aed", border:"none", borderRadius:6, width:26, height:26, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                          <Pencil size={12}/>
                        </button>
                        <button className="mc-cat-icon-btn" title="Delete" type="button"
                          onClick={e=>{ e.stopPropagation(); openDeleteModal({ type:"category", id:cat.categoryId }); }}
                          style={{ background:"#fee2e2", color:"#ef4444", border:"none", borderRadius:6, width:26, height:26, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                          <Trash2 size={12}/>
                        </button>
                        <ChevronRight size={13} style={{ color:"#d4d4d8" }}/>
                      </div>
                      {/* Always-visible icons for selected */}
                      {selectedCatId === cat.categoryId && (
                        <div className="mc-cat-row-actions" onClick={e=>e.stopPropagation()}
                          style={{ display:"flex", alignItems:"center", gap:3 }}>
                          <button className="mc-cat-icon-btn" title="Edit" type="button"
                            onClick={e=>handleEditCategory(cat,e)}
                            style={{ background:"#ede9fe", color:"#7c3aed", border:"none", borderRadius:6, width:26, height:26, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                            <Pencil size={12}/>
                          </button>
                          <button className="mc-cat-icon-btn" title="Delete" type="button"
                            onClick={e=>{ e.stopPropagation(); openDeleteModal({ type:"category", id:cat.categoryId }); }}
                            style={{ background:"#fee2e2", color:"#ef4444", border:"none", borderRadius:6, width:26, height:26, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                            <Trash2 size={12}/>
                          </button>
                          <ChevronRight size={13} style={{ color:"#d4d4d8" }}/>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))
            )}
          </div>
        </aside>

        {/* ── MAIN CONTENT ─────────────────────────────────── */}
        <div className="mc-main">
          <div className="mc-form-panel shadow-sm hover:shadow-md transition-shadow duration-300 rounded-2xl">
            <div className="mc-form-head">
              <h2 className="mc-form-title">{editingItem ? `${t("mc_edit_prefix")} ${editingItem.itemName}` : t("mc_add_new_item")}</h2>
              <button className="mc-collapse-btn" onClick={() => setFormCollapsed(v => !v)} type="button">
                {formCollapsed ? <><ChevronDown size={16} /> {t("mc_expand")}</> : <><ChevronUp size={16} /> {t("mc_collapse")}</>}
              </button>
            </div>

            {!formCollapsed && (
              <div className="mc-form-body">

                {/* ── CATEGORY ROW ──────────────────────── */}
                <div className="mc-form-row mc-form-cat-row">
                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_category_label")} <span className="mc-req">*</span></label>

                    {/* Category suggestion dropdown */}
                    {catSuggestions.length > 0 && (
                      <div style={{ position: "relative", marginBottom: 8 }}>
                        <button
                          type="button"
                          onClick={() => { setShowFormCatDrop(v => !v); setShowFormItemDrop(false); }}
                          style={{
                            display: "flex", alignItems: "center", gap: 6, width: "100%",
                            padding: "8px 12px", background: "#fffbeb", border: "1.5px solid #fde68a",
                            borderRadius: 8, fontSize: 12.5, fontWeight: 600, color: "#92400e",
                            cursor: "pointer", justifyContent: "space-between"
                          }}
                        >
                          <span>{t("mc_suggested_categories")} ({catSuggestions.length})</span>
                          <ChevronDown size={14} style={{ transform: showFormCatDrop ? "rotate(180deg)" : "none", transition: "0.2s" }} />
                        </button>
                        {showFormCatDrop && (
                          <div style={suggDropStyle}>
                            <div className="sugg-drop-header">{t("mc_based_on_business_type")}</div>
                            {catSuggestions.map((s, i) => (
                              <button key={i} type="button"
                                style={suggItemStyle(false)}
                                onMouseEnter={e => e.currentTarget.style.background = "#fffbeb"}
                                onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                                onClick={() => {
                                  handleFieldChange("newCategoryName", s.categoryName);
                                  handleFieldChange("categoryId", "");
                                  setShowFormCatDrop(false);
                                }}
                              >
                                {s.categoryEmoji && <span style={{ fontSize: 16 }}>{s.categoryEmoji}</span>}
                                <span>{s.categoryName}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="mc-select-wrap">
                      <select className={`mc-select ${formErrors.category ? "mc-err" : ""}`}
                        value={form.categoryId}
                        onChange={e => { handleFieldChange("categoryId", e.target.value); handleFieldChange("newCategoryName", ""); }}>
                        <option value="">{t("mc_select_existing_category")}</option>
                        {categories.map(c => <option key={c.categoryId} value={String(c.categoryId)}>{c.categoryName}</option>)}
                      </select>
                      <ChevronDown size={15} className="mc-select-icon" />
                    </div>
                    {formErrors.category && <span className="mc-field-err">{formErrors.category}</span>}
                  </div>

                  <div className="mc-form-or">{t("mc_or")}</div>

                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_new_category_name")}</label>
                    <input className="mc-input" type="text"
                      placeholder={t("mc_new_category_ph")}
                      value={form.newCategoryName}
                      onChange={e => { handleFieldChange("newCategoryName", e.target.value); handleFieldChange("categoryId", ""); }} />
                    <span style={{ fontSize: 11, color: "#a1a1aa", marginTop: 3, display: "block" }}>
                      {t("mc_not_in_dropdown_hint")}
                    </span>
                  </div>
                </div>

                {/* ── ITEM NAME ROW ──────────────────────── */}
                <div className="mc-form-row">
                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_item_name")} <span className="mc-req">*</span></label>

                    {/* Item suggestion dropdown — shows only after category is chosen */}
                    {currentCategoryName && (
                      <div style={{ position: "relative", marginBottom: 8 }}>
                        {loadingItemSugg ? (
                          <div style={{ fontSize: 12, color: "#a1a1aa", display: "flex", alignItems: "center", gap: 6, padding: "6px 0" }}>
                            <Loader2 size={12} style={{ animation: "spin .7s linear infinite" }} />
                            {t("mc_loading_suggestions_for")} "{currentCategoryName}"...
                          </div>
                        ) : itemSuggestions.length > 0 ? (
                          <>
                            <button
                              type="button"
                              onClick={() => { setShowFormItemDrop(v => !v); setShowFormCatDrop(false); }}
                              style={{
                                display: "flex", alignItems: "center", gap: 6, width: "100%",
                                padding: "8px 12px", background: "#f0fdf4", border: "1.5px solid #bbf7d0",
                                borderRadius: 8, fontSize: 12.5, fontWeight: 600, color: "#166534",
                                cursor: "pointer", justifyContent: "space-between"
                              }}
                            >
                              <span>{t("mc_suggested_items_for")} "{currentCategoryName}" ({itemSuggestions.length})</span>
                              <ChevronDown size={14} style={{ transform: showFormItemDrop ? "rotate(180deg)" : "none", transition: "0.2s" }} />
                            </button>
                            {showFormItemDrop && (
                              <div style={suggDropStyle}>
                                <div className="sugg-drop-header">{t("mc_tap_to_fill")}</div>
                                {itemSuggestions.map((s, i) => (
                                  <button key={i} type="button"
                                    style={suggItemStyle(false)}
                                    onMouseEnter={e => e.currentTarget.style.background = "#f0fdf4"}
                                    onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                                    onClick={() => {
                                      handleFieldChange("name", s.itemName);
                                      setShowFormItemDrop(false);
                                    }}
                                  >
                                    {s.itemImage ? <img src={s.itemImage} alt="" style={{ width:22, height:22, borderRadius:5, objectFit:"cover", flexShrink:0 }}/> : <span style={{ fontSize: 16 }}>🍽️</span>}
                                    <span>{s.itemName}</span>
                                  </button>
                                ))}
                              </div>
                            )}
                          </>
                        ) : (
                          <div style={{ fontSize: 11.5, color: "#a1a1aa", padding: "4px 0" }}>
                            {t("mc_no_suggestions_type_manually")}
                          </div>
                        )}
                      </div>
                    )}

                    <div className={`mc-input-icon-wrap ${formErrors.name ? "mc-err" : ""}`}>
                      <span className="mc-input-icon"><Coffee size={15} /></span>
                      <input className="mc-input-inner" type="text"
                        placeholder={currentCategoryName ? t("mc_item_name_ph_with_sugg") : t("mc_item_name_ph_plain")}
                        value={form.name}
                        onChange={e => handleFieldChange("name", e.target.value)} />
                    </div>
                    {formErrors.name && <span className="mc-field-err">{formErrors.name}</span>}
                  </div>

                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_item_description_optional")}</label>
                    <div className="mc-input-icon-wrap">
                      <span className="mc-input-icon"><Filter size={14} /></span>
                      <input className="mc-input-inner" type="text" placeholder={t("mc_item_description_ph")}
                        value={form.description} onChange={e => handleFieldChange("description", e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* ── IMAGE + PRICE ROW ──────────────────── */}
                <div className="mc-form-row">
                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_item_image_optional")}</label>
                    <ImageUploadBox imageUrl={form.imageUrl} onUpload={handleProdImageUpload} onRemove={() => handleFieldChange("imageUrl", null)} uploading={prodImgUploading} t={t} />
                  </div>
                  <div className="mc-form-group mc-fg-half">
                    <label className="mc-label">{t("mc_item_price")} <span className="mc-req">*</span></label>
                    <div className={`mc-input-icon-wrap ${formErrors.price ? "mc-err" : ""}`}>
                      <span className="mc-input-icon mc-rupee">{currencyReady ? getCurrencySymbol(currencyCode) : "…"}</span>
                      <input className="mc-input-inner" type="number" min="0" step="0.01" placeholder="0.00"
                        value={form.price} onChange={e => handleFieldChange("price", e.target.value)} />
                    </div>
                    {formErrors.price && <span className="mc-field-err">{formErrors.price}</span>}
                    <label className="mc-label" style={{ marginTop: 14 }}>{t("mc_status")}</label>
                    <div className="mc-select-wrap">
                      <select className="mc-select" value={form.status} onChange={e => handleFieldChange("status", e.target.value)}>
                        <option value="ACTIVE">{t("mc_active")}</option>
                        <option value="INACTIVE">{t("mc_inactive")}</option>
                      </select>
                      <ChevronDown size={15} className="mc-select-icon" />
                    </div>

                    {/* ── Item Availability (In Stock / Out of Stock) ──
                        Separate from productStatus above: status controls
                        whether the item shows on the menu at all; this
                        controls whether a visible item can be ordered. */}
                    <label className="mc-label" style={{ marginTop: 14 }}>{t("mc_item_availability")}</label>
                    <div className="mc-select-wrap">
                      <select
                        className={`mc-select ${form.itemAvailability === "OUT_OF_STOCK" ? "mc-select-oos" : "mc-select-available"}`}
                        value={form.itemAvailability}
                        onChange={e => handleFieldChange("itemAvailability", e.target.value)}
                      >
                        <option value="AVAILABLE">{t("mc_available")}</option>
                        <option value="OUT_OF_STOCK">{t("mc_out_of_stock")}</option>
                      </select>
                      <ChevronDown size={15} className="mc-select-icon" />
                    </div>

                    {/* ── Special Item (Chef's Special / Signature Dish) ──
                        Merchant-curated highlight shown on the customer
                        landing page's "Special Items" section. */}
                    <label
                      className="mc-special-checkbox"
                      style={{ marginTop: 14 }}
                    >
                      <input
                        type="checkbox"
                        checked={!!form.specialItem}
                        onChange={e => handleFieldChange("specialItem", e.target.checked)}
                      />
                      <span className="mc-special-checkbox-box">
                        <Check size={12} />
                      </span>
                      <span className="mc-special-checkbox-label">
                        ⭐ {t("mc_special_item")}
                      </span>
                    </label>
                    <span style={{ fontSize: 11, color: "#a1a1aa", marginTop: 3, display: "block" }}>
                      {t("mc_special_item_hint")}
                    </span>
                  </div>
                </div>

                <div className="mc-form-actions">
                  <button className="mc-btn-reset" onClick={resetForm} type="button" disabled={formSaving}><RotateCcw size={14} /> {t("mc_reset")}</button>
                  <button className="mc-btn-dark mc-save-btn shadow-sm hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-sm transition-all duration-200" onClick={handleSaveItem} type="button" disabled={formSaving || prodImgUploading}>
                    {formSaving
                      ? <><Loader2 size={14} style={{ animation: "spin .7s linear infinite" }} /> {editingItem ? t("mc_updating") : t("mc_saving")}</>
                      : <><Send size={14} /> {editingItem ? t("mc_update_item") : t("mc_save_item")}</>}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ── ITEMS TABLE ──────────────────────────────── */}
          <div className="mc-items-panel shadow-sm hover:shadow-md transition-shadow duration-300 rounded-2xl">
            <div className="mc-items-head">
              <h3 className="mc-items-title">
                {selectedCategory ? `${t("mc_items_in")} ${selectedCategory.categoryName}` : t("mc_select_category_short")} ({totalItems})
              </h3>
              <div className="mc-items-controls">
                <div className="mc-search-wrap">
                  <Search size={14} className="mc-search-icon" />
                  <input className="mc-search-input" type="text" placeholder={t("mc_search_items_ph")}
                    value={searchQuery} onChange={e => { setSearchQuery(e.target.value); setCurrentPage(1); }} />
                </div>
                <div className="mc-select-wrap mc-status-select">
                  <select className="mc-select" value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setCurrentPage(1); }}>
                    <option>{t("mc_all_status")}</option><option>{t("mc_active")}</option><option>{t("mc_inactive")}</option>
                  </select>
                  <ChevronDown size={14} className="mc-select-icon" />
                </div>
                <button className="mc-icon-btn" onClick={() => selectedCatId && fetchProducts(selectedCatId)} title={t("mc_refresh")} type="button"><RefreshCw size={15} /></button>
              </div>
            </div>

            <div className="mc-table-wrap rounded-xl overflow-hidden">
              <table className="mc-table">
                <thead>
                  <tr>
                    <th className="mc-th">{t("mc_item_th")}</th><th className="mc-th">{t("mc_description_th")}</th>
                    <th className="mc-th">{t("mc_price_th")}</th><th className="mc-th">{t("mc_status_th")}</th>
                    <th className="mc-th">{t("mc_availability_th")}</th>
                    <th className="mc-th">{t("mc_special_th")}</th>
                    <th className="mc-th mc-th-right">{t("mc_actions_th")}</th>
                  </tr>
                </thead>
                <tbody>
                  {prodsLoading ? (
                    <tr><td colSpan={7} className="mc-empty"><div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}><Loader2 size={16} style={{ animation: "spin .7s linear infinite" }} /> {t("mc_loading")}</div></td></tr>
                  ) : !selectedCatId ? (
                    <tr><td colSpan={7} className="mc-empty">{t("mc_select_category_hint")}</td></tr>
                  ) : pagedProducts.length === 0 ? (
                    <tr><td colSpan={7} className="mc-empty">{searchQuery || statusFilter !== "All Status" ? t("mc_no_items_match") : t("mc_no_items_yet")}</td></tr>
                  ) : (
                    pagedProducts.map(item => {
                      const isOOS = item.itemAvailability === "OUT_OF_STOCK";
                      const togglingThis = availabilitySavingId === item.productId;
                      const togglingSpecial = specialSavingId === item.productId;
                      return (
                      <tr key={item.productId} className="mc-tr">
                        <td className="mc-td">
                          <div className="mc-item-cell">
                            <div className="mc-item-thumb">
                              {item.itemImageUrl ? <img src={item.itemImageUrl} alt={item.itemName} className="mc-thumb-img" onError={e => { e.target.style.display = "none"; e.target.nextSibling.style.display = "flex"; }} /> : null}
                              <span className="mc-thumb-emoji" style={{ display: item.itemImageUrl ? "none" : "flex" }}>🍽️</span>
                            </div>
                            <span className="mc-item-name">{item.itemName}</span>
                          </div>
                        </td>
                        <td className="mc-td mc-td-desc">{item.itemDescription || "—"}</td>
                        <td className="mc-td mc-td-price">{currencyReady ? formatCurrency(Number(item.itemPrice), currencyCode) : "…"}</td>
                        <td className="mc-td">
                          <span className={`mc-status-badge ${item.productStatus === "ACTIVE" ? "mc-status-active" : "mc-status-inactive"}`}>
                            <span className="mc-status-dot" />{item.productStatus === "ACTIVE" ? t("mc_active") : t("mc_inactive")}
                          </span>
                        </td>
                        <td className="mc-td">
                          <button
                            type="button"
                            className={`mc-avail-badge ${isOOS ? "mc-avail-oos" : "mc-avail-available"}`}
                            onClick={() => handleToggleAvailability(item)}
                            disabled={togglingThis}
                            title={isOOS ? t("mc_tap_to_mark_available") : t("mc_tap_to_mark_out_of_stock")}
                          >
                            {togglingThis
                              ? <Loader2 size={12} style={{ animation: "spin .7s linear infinite" }} />
                              : <span className="mc-avail-dot" />}
                            {isOOS ? t("mc_out_of_stock") : t("mc_available")}
                          </button>
                        </td>
                        <td className="mc-td">
                          <button
                            type="button"
                            className={`mc-special-badge ${item.specialItem ? "mc-special-on" : "mc-special-off"}`}
                            onClick={() => handleToggleSpecial(item)}
                            disabled={togglingSpecial}
                            title={item.specialItem ? t("mc_tap_to_unmark_special") : t("mc_tap_to_mark_special")}
                          >
                            {togglingSpecial
                              ? <Loader2 size={12} style={{ animation: "spin .7s linear infinite" }} />
                              : <Star size={12} fill={item.specialItem ? "currentColor" : "none"} />}
                            {item.specialItem ? t("mc_special") : t("mc_regular")}
                          </button>
                        </td>
                        <td className="mc-td mc-td-actions">
                          <button className="mc-action-edit" onClick={() => handleEdit(item)} type="button"><Pencil size={13} /> {t("mc_edit_action")}</button>
                          <button className="mc-action-delete" onClick={() => openDeleteModal({ type: "product", id: item.productId })} type="button"><Trash2 size={13} /> {t("mc_delete_action")}</button>
                        </td>
                      </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {filteredProducts.length > ITEMS_PER_PAGE && (
              <div className="mc-pagination">
                <span className="mc-pg-info">
                  {t("mc_showing")} {Math.min((safePage - 1) * ITEMS_PER_PAGE + 1, filteredProducts.length)} {t("mc_to")} {Math.min(safePage * ITEMS_PER_PAGE, filteredProducts.length)} {t("mc_of_items")} {filteredProducts.length} {t("mc_items_word")}
                </span>
                <div className="mc-pg-controls">
                  <button className="mc-pg-btn" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={safePage === 1} type="button"><ChevronLeft size={15} /></button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(pg => (
                    <button key={pg} className={`mc-pg-btn ${safePage === pg ? "mc-pg-active" : ""}`} onClick={() => setCurrentPage(pg)} type="button">{pg}</button>
                  ))}
                  <button className="mc-pg-btn" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={safePage === totalPages} type="button"><ChevronRight size={15} /></button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuCategory;